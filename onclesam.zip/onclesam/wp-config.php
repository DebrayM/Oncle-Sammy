<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'onclesam' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ClD?gCZC$ a2eyzUkyA^PObSaf;>R< F^39f3&5d]!F>7SC=F uop9&d*tcJE^?3' );
define( 'SECURE_AUTH_KEY',  'DIUlx:Zj~}Yb)Vb{=nh}Pi4$)^~ZQ::]/0.6*HcfPGKT h2wWGou]z^1ZlvTVTlw' );
define( 'LOGGED_IN_KEY',    'A]rv9=O`Sb*I{Q{>;3@$diPqJ~y]E/eows|j2.{2tr|j)Gj$p;(yLLE@c.xB)O/X' );
define( 'NONCE_KEY',        '{PYT.Na2(Z|AKn/j|z)k,WeCvif-Ek|5ox7+BoX1clLyvxpPJJz|q{*1vy6{1[:V' );
define( 'AUTH_SALT',        ':s[q|r#YgomHr0KjDHBh-t=@7|;(9hgG8K%]p9r@cpM^BQ :[TR^Wz.xpu?Kg,Ee' );
define( 'SECURE_AUTH_SALT', '>{^6 +u?5JE{N)h_n~K4x5/[oe@,u4^Vf, *7B1|*#:n|+bG,AW/bD^H?[x9XbH!' );
define( 'LOGGED_IN_SALT',   '?P6~]{UK.2eNSm@-k?gt#&PAwH*W! 9U6W;b`]XYz-hoB4]Za#J%d_f8vEOQCvz)' );
define( 'NONCE_SALT',       '/ 9A[)*/DQYT&.Kh$=ba<M^uCV3FS !0iG^;+e*2B7itT5g+S[C@VsT||LnoLz+m' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'os';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
